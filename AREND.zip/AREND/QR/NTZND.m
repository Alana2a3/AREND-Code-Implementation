function output = NTZND(t5, x)
    lambda = 30;
    gamma = 60;
    Q = x(1:25, 1);
    r = x(26:40, 1);

    Q = reshape(Q, 5, 5);
    Rq = [r(1),r(2),r(4),r(7), r(11);
             0,r(3),r(5),r(8), r(12);
             0,   0,r(6),r(9), r(13);
             0,   0,   0,r(10),r(14);
             0,   0,   0,   0, r(15)];

    B = MatrixB(t5);
    DotB = dotB(t5);
    vecDotB = reshape(DotB, 25, 1);
    Q_DotB = Q' * DotB;
    vecQ_DotB = reshape(Q_DotB, 25, 1);

    Pq = MatrixPq(5, 5);
    Gr = MatrixGr(5, 5);

    M11 = -kron(Rq', eye(5));
    M12 = -kron(eye(5), Q) * Gr;
    M21 = kron(Q', eye(5)) * Pq + kron(eye(5), Q');
    M22 = zeros(25, 15);
    M31 = kron(B', eye(5)) * Pq;
    M32 = -kron(eye(5), eye(5)) * Gr;

    M = [M11, M12;
         M21, M22;
         M31, M32];

    err1 = B - Q * Rq;
    err2 = Q' * Q - eye(5);
    err3 = Q' * B - Rq;

    inte1 = reshape(x(41:65), 5, 5);
    inte2 = reshape(x(66:90), 5, 5);
    inte3 = reshape(x(91:115), 5, 5);
    vec_err1 = reshape(err1,25,1);
    vec_err2 = reshape(err2,25,1);
    vec_err3 = reshape(err3,25,1);
    activated_err1 = gamma * err1;
    vec_activated_err1 = reshape(activated_err1, 25, 1);

    activated_err_inte1 = lambda * (inte1+inte2+inte3);

    activated1 = activated_err1 + activated_err_inte1; 
    vec_activated1 = reshape(activated1, 25, 1);
   
    
    
    activated_err2 = gamma * err2;
    vec_activated_err2 = reshape(activated_err2, 25, 1);

    activated_err_inte2 = lambda * (inte2+inte1+inte3);

    activated2 = activated_err2 + activated_err_inte2; 
    vec_activated2 = reshape(activated2, 25, 1);

    
    
    activated_err3 = gamma * err3;
    vec_activated_err3 = reshape(activated_err3, 25, 1);

    activated_err_inte3 = lambda * (inte3+inte1+inte2); 

    activated3 = activated_err3 + activated_err_inte3; 
    vec_activated3 = reshape(activated3, 25, 1);

    E1 = vec_activated1;
    E2 = vec_activated2;
    E3 = vec_activated3;
    
    f1 = -E1 - vecDotB;
    f2 = -E2;
    f3 = -E3 - vecQ_DotB;

    f = [f1; f2; f3];
    
    con_noise = 10;
    period_noise = 10*sin(3*t5);
    rand_noise = 10 + 2*rand(40,1);
    
    dotx = pinv(M) * f +period_noise;

    output = [dotx; vec_err1; vec_err2; vec_err3];
    t5
end
