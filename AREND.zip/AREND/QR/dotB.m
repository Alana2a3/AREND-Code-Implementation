function output = dotB(t)
output = [cos(t), -sin(t), 2*cos(2*t), -2*sin(2*t), 3*cos(3*t);
        -3*sin(3*t), 4*cos(4*t), -4*sin(4*t), 5*cos(5*t), -5*sin(5*t);
        6*cos(6*t), -6*sin(6*t), 7*cos(7*t), -7*sin(7*t), 8*cos(8*t);
        -8*sin(8*t), 9*cos(9*t), -9*sin(9*t), 10*cos(10*t), -10*sin(10*t);
        11*cos(11*t), -11*sin(11*t), 12*cos(12*t), -12*sin(12*t), 13*cos(13*t)
    ];
% output = [3*cos(3*t), cos(t), -1.5*sin(0.5*t), -2*sin(t), cos(t);
%         2*cos(2*t), -sin(t), -2*sin(t), 6*cos(6*t), cos(t);
%         cos(t), -1.5*sin(t), -sin(t), -sin(t+1), -2*sin(t);
%         1, 0.5*cos(t), -2.5*sin(t), 5, -sin(t);
%         2*cos(2*t), 0.5, cos(t), -4*sin(t), 3*cos(3*t)];
% output = [1, 0.5*exp(0.5*t), 2*pi*cos(2*pi*t), -2*pi*sin(2*pi*t), exp(t) + t.*exp(t);
%         1 + 2*t, exp(t), 2*pi*sqrt(2)*cos(2*pi*sqrt(2)*t), -2*pi*sqrt(2)*sin(2*pi*sqrt(2)*t + pi/4), -t.^2.*exp(-t) + 2*t.*exp(-t);
%         2*t, -0.5*exp(-0.5*t), 2*pi*sqrt(3)*cos(2*pi*sqrt(3)*t), -2*pi*sqrt(3)*sin(2*pi*sqrt(3)*t), exp(0.5*t) + 0.5*t.*exp(0.5*t);
%         3*t^2, -exp(-t), 2*pi*sqrt(5)*cos(2*pi*sqrt(5)*t), -2*pi*sqrt(5)*sin(2*pi*sqrt(5)*t + pi/4), -0.5*t.^2.*exp(-0.5*t) + 2*t.*exp(-0.5*t);
%         -1 + 4*t^3, 1.5*exp(1.5*t), 2*pi*sqrt(7)*cos(2*pi*sqrt(7)*t), -2*pi*sqrt(7)*sin(2*pi*sqrt(7)*t), 3*t.^2.*exp(t) + t.^3.*exp(t)];