% function output = N_Acf(x)
% X = reshape(x,3,3);
% p = 1.5;
% output = exp(abs(X).^p) * abs(X).^(p-1) .* sign(X);
function output = N_Acf(x)
    X = reshape(x, 5, 5);
    p = 1.5;
   
    % Perform GPU computations
    output = exp(abs(X).^p) .* abs(X).^(p-1) .* sign(X);
    
    % Transfer result back to CPU
    output = reshape(output,25,1);
end
