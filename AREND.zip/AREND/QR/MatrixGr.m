% function Gr = MatrixGr(m,n)
%     
%     r = n * (n + 1) / 2;
%     Gr = zeros(m * n, r);
%     index = 1;
%     
%     for i = 1:m
%         for j = 1:n
%             if i >= j
%                 Gr((i - 1) * n + j, index) = 1;
%                 index = index + 1;
%             end
%         end
%     end
% end
% 
function Gr = MatrixGr(m,n)
    % 创建一个 m*n x n*(n+1)/2 的零矩阵
    Gr = zeros(m*n, n*(n+1)/2);

    % 索引变量
    k = 1;

    % 遍历 A 的每一列
    for j = 1:n
        % 遍历 A 的每一行，从对角线开始
        for i = 1:j
            % 计算此元素在 vec(A) 中的位置
            idx = (j-1)*m + i;

            % 设置 G 中的相应元素为 1
            Gr(idx, k) = 1;

            % 更新索引变量
            k = k + 1;
        end
    end
end