function m = VPF(t,err)
p = 3;
m = p^t+ 2*p*t + p;