function P = MatrixPq(m, n)
    % 初始化一个全零的 m*n x m*n 置换矩阵
    P = zeros(m*n, m*n);

    % 使用两个嵌套循环来设置置换矩阵的元素
    for i = 1:m
        for j = 1:n
            % 计算原矩阵 A 中元素的索引和转置后矩阵中元素的索引
            original_index = (j-1)*m + i;
            transposed_index = (i-1)*n + j;

            % 在置换矩阵中对应位置设置为 1
            P(original_index, transposed_index) = 1;
        end
    end
end