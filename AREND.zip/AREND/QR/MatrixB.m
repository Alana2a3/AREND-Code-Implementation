function output = MatrixB(t)
output =  [
        sin(t), cos(t), sin(2*t), cos(2*t), sin(3*t);
        cos(3*t), sin(4*t), cos(4*t), sin(5*t), cos(5*t);
        sin(6*t), cos(6*t), sin(7*t), cos(7*t), sin(8*t);
        cos(8*t), sin(9*t), cos(9*t), sin(10*t), cos(10*t);
        sin(11*t), cos(11*t), sin(12*t), cos(12*t), sin(13*t)
    ];
% output = [sin(3*t)+3,sin(t),3*cos(0.5*t),2*cos(t),sin(t)+1;
%     sin(2*t),cos(t),2*cos(t),sin(6*t),sin(t)-8;
%     sin(t),1.5*cos(t),cos(t)-3,cos(t+1),2*cos(t);
%     t,0.5*sin(t),2.5*cos(t),5*t,cos(t)-5;
%     sin(2*t)-2,0.5*t,sin(t),4*cos(t),sin(3*t)];
% output = [1 + t, exp(0.5*t), sin(2*pi*t), cos(2*pi*t), t.*exp(t);
%         1 - t + t^2, exp(t), sin(2*pi*sqrt(2)*t), cos(2*pi*sqrt(2)*t + pi/4), t.^2.*exp(-t);
%         2 + t^2, exp(-0.5*t), sin(2*pi*sqrt(3)*t), cos(2*pi*sqrt(3)*t), t.*exp(0.5*t);
%         -1 + t^3, exp(-t), sin(2*pi*sqrt(5)*t), cos(2*pi*sqrt(5)*t + pi/4), t.^2.*exp(-0.5*t);
%         3 - t + t^4, exp(1.5*t), sin(2*pi*sqrt(7)*t), cos(2*pi*sqrt(7)*t), t.^3.*exp(t)];
