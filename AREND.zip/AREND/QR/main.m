clc;
clear;
close all;
Q0 = (rand(25,1));
r0 = rand(15,1);
x0_1 = [Q0;r0];
x0_2 = [Q0;r0;zeros(75,1)];
tspan = [0,5];
options = odeset();

[t1,x1] = ode45(@AIRND,tspan,x0_2);
Errf1_1 = zeros(length(t1), 1);
Errf2_1 = zeros(length(t1), 1);
Errf3_1 = zeros(length(t1), 1);

for j = 1:length(t1)
    T = t1(j);
    B = MatrixB(T);
    Q = x1(j,1:25);
    r = x1(j,26:40);
    Q = reshape(Q,5,5);
    Rq = [r(1),r(2),r(4),r(7), r(11);
             0,r(3),r(5),r(8), r(12);
             0,   0,r(6),r(9), r(13);
             0,   0,   0,r(10),r(14);
             0,   0,   0,   0, r(15)];

    E1 = B - Q * Rq;
    E2 = Q' * Q - eye(5);
    E3 = Q' * B - Rq;

    Errf1_1(j) = norm(E1, 'fro');
    Errf2_1(j) = norm(E2, 'fro');
    Errf3_1(j) = norm(E3, 'fro');
end


