% 定义一个自适应激活函数
% X为输入矩阵
function output = AF_Adaptive(X)
    bound = 2;  % 阈值
    reshape_X = reshape(X, 25, 1);  % 将输入矩阵X转化为向量
    output = zeros(length(reshape_X), 1);  % 初始化输出
    
    % 对向量中的每个元素进行遍历
    for index = 1:length(reshape_X)
        if reshape_X(index) > bound  % 如果大于阈值，输出为阈值
            output(index) = bound;
        end
        if reshape_X(index) < -bound  % 如果小于阈值，输出为负阈值
            output(index) = -bound;
        end
        if reshape_X(index) <= bound && reshape_X(index) >= -bound  % 如果在阈值范围内，使用自适应公式计算输出值
            output(index) = (((abs(reshape_X(index))+1).^12)+12) .* reshape_X(index);
        end
    end
    
    output = reshape(output, 5, 5);  % 将输出向量重新转化为矩阵
end