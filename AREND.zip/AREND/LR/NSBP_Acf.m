function output = NSBP_Acf(x)
    tao = 0.4;
    output = 0.5*(abs(x).^tao+abs(x).^(1/tao)).*sign(x)+0.5*x;