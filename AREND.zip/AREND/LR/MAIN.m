clc;
clear;
tspan = [0,1];

x0_1 = 2*rand(9,1);
x0_2 = [x0_1;zeros(9,1)];
options =[];
tic;
[t1,x1] = ode45(@AREND,tspan,x0_2,options);

    for j = 1:length(t1)
        T = t1(j);  
        A = MatrixA(T);  
        l = x1(j,1:3);
        u = x1(j,4:9);
        RL = [u(1), u(2), u(4);
        0,u(3),u(5);
        0,0,u(6)];
        L = [1,0,0;
        l(1),1,0;
        l(2),l(3),1];
        temp = A - L * RL;  
        Err(:, j) = reshape(temp, 9, 1);  
        nerr1(j) = norm(Err(:,j));  
        
    end

