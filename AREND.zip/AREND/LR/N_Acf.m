% function output = N_Acf(x)
% X = reshape(x,3,3);
% p = 1.5;
% output = exp(abs(X).^p) * abs(X).^(p-1) .* sign(X);
function output = N_Acf(x)
    X = reshape(x, 3, 3);
    p = 1.5;
    
    % Move data to GPU
    X_gpu = gpuArray(X);
    
    % Perform GPU computations
    output_gpu = exp(abs(X_gpu).^p) .* abs(X_gpu).^(p-1) .* sign(X_gpu);
    
    % Transfer result back to CPU
    output = reshape(gather(output_gpu),9,1);
end
