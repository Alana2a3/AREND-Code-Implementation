function m = VPF(t,err)
p = 4;
m = p^t+ 2*p*t + p;