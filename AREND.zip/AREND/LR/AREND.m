function output = AREND(t1,x)
    lambda = 30;
    gamma = 60;
    l = x(1:3);  
    u = x(4:9);  

    RL = [u(1), u(2), u(4);
        0,u(3),u(5);
        0,0,u(6)];
        
    L = [1,0,0;
        l(1),1,0;
        l(2),l(3),1];
    
    A = MatrixA(t1);  

    err = A - L * RL;  
    [m,n] = size(err);
    
    inte = reshape(x(10:18), 3, 3);
    
    activated_err = gamma*AF_Adaptive(err);
    vec_activated_err = reshape(activated_err,9,1);

    activated_err_inte = lambda * AF_Adaptive(err + inte);

    activated = activated_err + activated_err_inte; 
    
    vec_activated = reshape(activated, m*n, 1);
    

    Zl = Z_L(A);  
    Zu = Z_U(A);  

    M1 = kron(RL',eye(3)) * Zl; 
    M2 = kron(eye(3),L) * Zu;  

    Ml = M1 + M2;  

    DotA = D_A(t1,A);  
    
    vecDotA = reshape(DotA,9,1);  
    fl = vecDotA + vec_activated;  
    dotx = pinv(Ml) * fl;  
    output = [dotx;vec_activated_err];
    t1
    
end
