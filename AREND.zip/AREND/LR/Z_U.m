function output = Z_U(A)
numl = (3 * 3 + 3) / 2;
k = 1;
Zu = zeros(3*3,3*3);
for i = 1 : numl 
    r = k * (k - 1) / 2;
    j = i + (3 - 1) * 3 / 2;
    if i <= (k + 1) * k / 2
        Zu(3 * (k - 1) + i - floor(r),j) = 1;
    end
    if i - (k + 1) * k /2 == 0
        k = k + 1;
    end
end
output = Zu;
end