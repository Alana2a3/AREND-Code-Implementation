function output = MatrixA(t)
output = [sin(t) + 3, sin(2 * t), sin(t);
    sin(t),cos(t) + 5,cos(2 * t);
    sin(t) - 1,cos(2 * t + 2),cos(t) + 3];
% output = [1+sin(t), t, log(1+t);
%     t^2, 1+cos(t), sqrt(t+1);
%     exp(t), t/(1+t), 2*sin(t/2)];