function output=DiffA(t,x)
syms u; A=MatrixA(u);
D=diff(A); 
u=t;
output=eval(D);
