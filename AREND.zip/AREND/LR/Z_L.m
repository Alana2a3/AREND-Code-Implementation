function output = Z_L(A)
numl = 3;
k = 1;
Zl = zeros(3*3,3*3);
for i = 1:numl
    r = floor((2 * 3 - k) * (k - 1) /2);
    if i <= (2 * 3 - k - 1)* k / 2 
        Zl(3 *(k - 1) + i - r + k, i) = 1;
    end
    if i - (2 * 3 - k - 1) * k / 2 == 0
        k = k + 1;
    end
end
output = Zl;