function RL = RL1(u, n)
    RL = zeros(n);
    idx = 1;
    for col = 1:n
        for row = 1:col
            RL(row, col) = u(idx);
            idx = idx + 1;
        end
    end
end