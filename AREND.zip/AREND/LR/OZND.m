function output = OZNN(t2,x)
    l = x(1:3);  
    u = x(4:9);  
    RL = [u(1), u(2), u(4);
        0,u(3),u(5);
        0,0,u(6)];
        
    L = [1,0,0;
        l(1),1,0;
        l(2),l(3),1];
    A = MatrixA(t2);  
    err = A - L * RL;  
    [m,n] = size(err);
    vecerr = reshape(err,m*n,1);  
    Zl = Z_L(A);  
    Zu = Z_U(A);  
    M1 = kron(RL',eye(3)) * Zl;  
    M2 = kron(eye(3),L) * Zu;  
    Ml = M1 + M2;  
    DotA = D_A(t2,A);  
    vecDotA = reshape(DotA,9,1); 
    fl = vecDotA + 5 *(vecerr);  
    dotx = pinv(Ml) * fl;  
    output = dotx;
    t2
    
end
