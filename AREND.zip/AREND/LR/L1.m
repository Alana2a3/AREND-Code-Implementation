function L = L1(l, n)
    L = eye(n);
    idx = 1;
    for col = 1:n-1
        for row = col+1:n
            L(row, col) = l(idx);
            idx = idx + 1;
        end
    end
end

